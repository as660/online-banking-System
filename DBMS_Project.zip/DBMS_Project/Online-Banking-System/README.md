# Online-Banking-System


This is a Database Project on Online Banking System in PHP.



The Online Banking System is an application for maintaining a person's account in a bank. 


In this project we have tried to show the working of a banking account system and cover the basic functionality of a 
Online Banking System. 


To develop a project for solving financial applications of a customer in banking environment in order to nurture the needs of an end banking user by providing various ways to perform banking tasks. 


Also, to enable the user’s work space to have additional functionalities which are not provided under a conventional banking project. 









The main aim of this project is to develop software for Online Banking System. 



This project has been developed to carry out the processes easily and quickly, which is not possible with the manual systems,
which are overcome by this software. 


In the present scenario the banking sector is the common need in everyday life. 


In day to day life we face problems and then we realize something is not done in this sector. 


In this process time is more as well as here more manual work is needed which increases man power. 


This project is developed using PHP programming language and MYSQL is used for database connection.


The project analyses the system requirements and then comes up with the requirements specifications. 


The system is then designed in accordance specifications to satisfy the requirements.







SOFTWARE REQUIREMENTS:



• Operating system : Windows XP/7/10.

•  Front End : PHP

•  Back end: MySQL

•  Database : MYSQL (Install XAMPP)

•  Server: XAMPP






Technologies used:

• PHP

• Mysql



