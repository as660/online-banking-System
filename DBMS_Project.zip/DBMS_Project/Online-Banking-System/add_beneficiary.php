<?php
    include "validate_customer.php";
    include "header.php";
    include "customer_navbar.php";
    include "customer_sidebar.php";
    include "session_timeout.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="customer_add_style.css?<?php echo time(); ?>">
    <title>Add Beneficiary</title>
</head>
<body>

    <form class="add-customer-form" action="add_beneficiary_action.php" method="post">

       <div class="heading">
        <h1>Add beneficiary details</h1>
        <p>Seamlessly add a new beneficiary and streamline your transactions</p>
        </div>

        <div class="form-group">
            <label for="fname">First Name:</label>
            <input name="fname" id="fname" type="text" required />
        </div>

        <div class="form-group">
            <label for="lname">Last Name:</label>
            <input name="lname" id="lname" type="text" required />
        </div>

        <div class="form-group">
            <label for="acno">Account No:</label>
            <input name="acno" id="acno" type="text" required />
        </div>

        <div class="form-group">
            <label for="email">Email-ID:</label>
            <input name="email" id="email" type="text" required />
        </div>

        <div class="form-group">
            <label for="phno">Phone No.:</label>
            <input name="phno" id="phno" type="text" required />
        </div>

        <div class="form-group">
            <a href="beneficiary.php" class="button">Go Back</a>
            <button type="submit">Submit</button>
            <button type="reset" class="reset" onclick="return confirmReset();">Reset</button>
        </div>
    </form>

    <script>
        function confirmReset() {
            return confirm('Do you really want to reset?');
        }
    </script>

</body>
</html>
