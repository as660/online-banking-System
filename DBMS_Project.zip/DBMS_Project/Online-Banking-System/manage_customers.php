<?php
include "validate_admin.php";
include "connect.php";
include "header.php";
include "user_navbar.php";
include "admin_sidebar.php";
include "session_timeout.php";

if (isset($_POST['submit'])) {
    $back_button = true;
    $search = $_POST['search'];
    $by = $_POST['by'];

    if ($by == "name") {
        $sql0 = "SELECT cust_id, first_name, last_name, account_no FROM customer
                 WHERE first_name LIKE ? OR last_name LIKE ?
                 OR CONCAT(first_name, ' ', last_name) LIKE ?";
    } else {
        $sql0 = "SELECT cust_id, first_name, last_name, account_no FROM customer
                 WHERE account_no LIKE ?";
    }

    $stmt = $conn->prepare($sql0);

    if ($by == "name") {
        $stmt->bind_param("sss", $search, $search, $search);
    } else {
        $stmt->bind_param("s", $search);
    }

    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $back_button = false;

    $sql0 = 'CALL `cust_details`()';
    $result = $conn->query($sql0);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="manage_customers_style.css?<?php echo time(); ?>" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
</head>

<body>
    <div class="search-bar-wrapper">
        <div class="search-bar" id="the-search-bar">
            <div class="flex-item-search-bar" id="fi-search-bar">
                <form class="search_form" action="" method="post">
                    <div class="flex-item-search">
                        <input name="search" size="30" type="text" placeholder="Search Customers..." />
                    </div>
                    <div class="flex-item-by">
                        <label>Sort By :</label>
                    </div>
                    <div class="flex-item-search-by">
                        <select name="by">
                            <option value="name">Name</option>
                            <option value="acno">Ac/No</option>
                        </select>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <table class="customer-table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Account Number</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($result->num_rows > 0) {
                $i = 0;
                while($row = $result->fetch_assoc()) {
                    $i++;
                    ?>
                    <tr>
                        <td><?php echo $i; ?></td>
                        <td><?php echo $row["first_name"] . " " . $row["last_name"]; ?></td>
                        <td><?php echo $row["account_no"]; ?></td>
                        <td>
                            <a href="edit_customer.php?cust_id=<?php echo $row["cust_id"] ?>">View / Edit</a>
                            <a href="transactions.php?cust_id=<?php echo $row["cust_id"] ?>">Transactions</a>
                            <a href="delete_customer.php?cust_id=<?php echo $row["cust_id"] ?>"
                                onclick="return confirm('Are you sure?')">Delete</a>
                        </td>
                    </tr>
                <?php }
            } else { ?>
                <tr>
                    <td colspan="4">No results found :(</td>
                </tr>
            <?php } ?>
        </tbody>
    </table>

    <?php
    if ($back_button) { ?>
        <div class="back_button">
            <a href="manage_customers.php" class="button">Go Back</a>
        </div>
    <?php }
    $conn->close(); ?>

    <script src="https://code.jquery.com/jquery-3.6.4
