<?php
    include "header.php";
    include "navbar.php";
    include "connect.php";
?>

<!DOCTYPE html>
<html>
<head>
 
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="news_style.css?<?php echo time(); ?>" />

</head>

<body>
    <div class="hero-section">
        <h2>Dadri Bank News Portal</h2>
        <p>Stay informed with the latest news and updates from around the world.</p>
    </div>
<table>
        <thead>
            <tr>
                <th>S.no</th>
                <th>Title</th>
                <th>Date</th>
                <th>News</th>
            </tr>
        </thead>
        <tbody>
            <?php

            $sql0 = "SELECT id, title, created FROM news ORDER BY created DESC";
            $result = $conn->query($sql0);

            if ($result->num_rows > 0) {
                $count = 1;
                while($row = $result->fetch_assoc()) {
                    $id = $row["id"];
                    $sql1 = "SELECT body FROM news_body WHERE id=$id";
                    $result1 = $conn->query($sql1); ?>

                    <tr>
                        <td><?php echo $count; ?></td>
                        <td id="title"><?php echo $row["title"]; ?></td>
                        <td id="date"><?php echo date("d/m/Y", strtotime($row["created"])); ?></td>
                        <td id="news_body"><?php while($row1 = $result1->fetch_assoc()) {
                            echo $row1["body"];
                        } ?></td>
                    </tr>
                    <?php
                    $count++;
                }
            } else {
                echo "<tr><td colspan='4'>No news available! Please post some.</td></tr>";
            }

            $conn->close();
            ?>
        </tbody>
    </table>
</body>
</html>
