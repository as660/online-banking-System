<?php
    include "header.php";

  
  if (isset($_GET['loginFailed'])) {
        $message = "Invalid Credentials ! Please try again.";
    
    echo "<script type='text/javascript'>alert('$message');</script>";
    }
?>

<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="admin_login_style.css?<?php echo time(); ?>" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
</head>


<body>
  
  <form action="admin_login_action.php" method="post">
        <div class="flex-container-1">
          
  <div class="flex-item">
                <h2>Administrator Login</h2>
     
       </div>

            <label><b>Username</b></label>
            <div class="flex-item">
                <input type="text" name="admin_uname" required>
   
         </div>

            <label><b>Password</b></label>
            <div class="flex-item">
                <input type="password" name="admin_psw" required>
  
          </div>
        </div>

        <div class="flex-container-2">
            <div class="flex-item">
                <button type="submit">Login</button>
   
         </div>

            <div class="flex-item">
                <button type="button" class="cancelbtn">Cancel</button>
            </div>
   
     </div>
    </form>


</body>

</html>
