<?php
    include "validate_customer.php";
    include "header.php";
    include "customer_navbar.php";
    include "customer_sidebar.php";
    include "session_timeout.php";

    if (isset($_GET['cust_id'])) {
        $id = $_GET['cust_id'];
    }

    $sql0 = "SELECT * FROM customer WHERE cust_id=".$id;
    $result0 = $conn->query($sql0);
    $row0 = $result0->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="send_funds_style.css?<?php echo time(); ?>">
    <title>Transfer Funds</title>
</head>
<body>
    <form class="transfer-form" action="send_funds_action.php?cust_id=<?php echo $id ?>" method="post">
        <div class="form-header">
            <h1>Transfer Funds</h1>
        </div>

        <div class="form-group">
            <label>To:</label>
            <label id="info-label"><?php echo $row0["first_name"]." ".$row0["last_name"] ?></label>
        </div>

        <div class="form-group">
            <label>Account No:</label>
            <label id="info-label"><?php echo $row0["account_no"] ?></label>
        </div>

        <div class="form-group">
            <label>Enter Amount (in INR):</label>
            <input name="amt" size="24" type="text" required />
        </div>

        <div class="form-group">
            <label>Enter your password:</label>
            <input name="password" size="24" type="password" required />
        </div>

        <div class="button-container">
            <button href="beneficiary.php" class="button">Go Back</button>
            <button type="submit" class="submit">Submit</button>
            <button type="reset" class="reset" onclick="return confirmReset();">Reset</button>
        </div>
    </form>

    <script>
        function confirmReset() {
            return confirm('Do you really want to reset?');
        }
    </script>
</body>
</html>
