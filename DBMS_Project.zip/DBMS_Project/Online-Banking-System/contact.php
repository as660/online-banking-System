<?php
include 'navbar.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="contact_style.css?<?php echo time(); ?>" />
</head>
<body>
    <div class="main-container">
        <div class="info-container">
            <div class="text-container">
                <div class="title">Get in touch with us for more information</div>
                <p>If you need help or have a question, we are here for you</p>
            </div>
        </div>
        </div>
    </div>
</body>
</html>
