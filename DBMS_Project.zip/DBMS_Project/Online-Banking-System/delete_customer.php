<?php
// Avoid multiple sessions warning
if (!isset($_SESSION)) {
    session_start();
}

include "validate_admin.php";
include "connect.php";
include "header.php";
include "user_navbar.php";
include "admin_sidebar.php";
include "session_timeout.php";

if (isset($_GET['cust_id'])) {
    $_SESSION['cust_id'] = $_GET['cust_id'];
}

$sql0 = "DELETE FROM customer WHERE cust_id=" . $_SESSION['cust_id'];
$sql1 = "DROP TABLE IF EXISTS passbook" . $_SESSION['cust_id'];
$sql2 = "DROP TABLE IF EXISTS beneficiary" . $_SESSION['cust_id'];

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="delete_customer_style.css?<?php echo time(); ?>" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap"
        rel="stylesheet">
</head>

<body>
    <div class="flex-container">
        <?php
        function executeQuery($conn, $sql, $successMessage)
        {
            if ($conn->query($sql) === TRUE) {
                echo "<p id='info'>$successMessage</p>";
            } else {
                echo "<p id='info'>Error: $sql <br> " . $conn->error . "<br></p>";
            }
        }

        executeQuery($conn, $sql0, "Customer Deleted Successfully!");
        executeQuery($conn, $sql1, "Customer's Passbook Deleted Successfully!");
        executeQuery($conn, $sql2, "Customer's Beneficiary Deleted Successfully!");

        $conn->close();
        ?>

        <div class="flex-item">
            <a href="manage_customers.php" class="button">Go Back</a>
        </div>
    </div>

</body>

</html>
